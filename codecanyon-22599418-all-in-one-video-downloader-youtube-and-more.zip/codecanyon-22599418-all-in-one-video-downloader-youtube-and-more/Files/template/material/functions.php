<?php
function get_domain($url)
{
    $pieces = parse_url($url);
    $domain = isset($pieces['host']) ? $pieces['host'] : '';
    if (preg_match('/(?P<domain>[a-z0-9][a-z0-9\-]{1,63}\.[a-z\.]{2,6})$/i', $domain, $regs)) {
        return $regs['domain'];
    }
    return false;
}

function build_menu($footer = false)
{
    $menu = json_decode(option("theme.menu"), true);
    if (!empty($menu)) {
        foreach ($menu as $node) {
            if (!empty($node['title']) && !empty($node['url'])) {
                if ($footer === true) {
                    echo '<li><a target="_blank" href="' . $node['url'] . '">' . $node['title'] . '</a></li>';
                } else {
                    echo '<li class="nav-item"><a target="_blank" class="nav-link" href="' . $node['url'] . '">' . $node['title'] . '</a></li>';
                }
            }
        }
    }
}

function social_links()
{
    $social_links = json_decode(option("theme.general"), true);
    foreach ($social_links as $link => $key) {
        if (!empty($key)) {
            switch ($link) {
                case 'facebook':
                    echo '<a class="btn btn-sm btn-social btn-fill btn-facebook" href="https://facebook.com/' . $key . '"><i class="fab fa-facebook-f"></i></a>';
                    break;
                case 'twitter':
                    echo '<a class="btn btn-sm btn-social btn-fill btn-twitter" href="https://twitter.com/' . $key . '"><i class="fab fa-twitter"></i></a>';
                    break;
                case 'youtube':
                    echo '<a class="btn btn-sm btn-social btn-fill btn-youtube" href="https://youtube.com/' . $key . '"><i class="fab fa-youtube"></i></a>';
                    break;
                /*
            case 'google':
                echo '<a class="btn btn-sm btn-social btn-fill btn-google-plus" href="https://plus.google.com/' . $key . '"><i class="fab fa-google-plus-g"></i></a>';
                break;
                */
                case 'instagram':
                    echo '<a class="btn btn-sm btn-social btn-fill btn-instagram" href="https://instagram.com/' . $key . '"><i class="fab fa-instagram"></i></a>';
                    break;
            }
        }
    }
}

function list_languages()
{
    foreach (glob(__DIR__ . "/../../language/*.php") as $filename) {
        if (basename($filename) != "index.php") {
            $language = str_replace(".php", null, basename($filename));
            if (language_exists($language) === true) {
                echo '<a class="dropdown-item" href="?lang=' . $language . '">' . strtoupper($language) . '</a>';
            }
        }
    }
}

function get_supported_websites(){
    $websites = array(
        array("name" => "9gag", "color" => "#000000", "slug" => ""),
        array("name" => "bandcamp", "color" => "#21759b", "slug" => "", "music" => true),
        array("name" => "blogger", "color" => "#fc4f08", "slug" => ""),
        array("name" => "break", "color" => "#b92b27", "slug" => ""),
        array("name" => "buzzfeed", "color" => "#df2029", "slug" => ""),
        array("name" => "dailymotion", "color" => "#0077b5", "slug" => ""),
        array("name" => "espn", "color" => "#df2029", "slug" => ""),
        array("name" => "facebook", "color" => "#3b5998", "slug" => ""),
        array("name" => "flickr", "color" => "#ff0084", "slug" => ""),
        array("name" => "imdb", "color" => "#eb4924", "slug" => ""),
        array("name" => "imgur", "color" => "#02b875", "slug" => ""),
        array("name" => "instagram", "color" => "#e4405f", "slug" => ""),
        array("name" => "izlesene", "color" => "#ff6600", "slug" => ""),
        array("name" => "likee", "color" => "#be3cfa", "slug" => ""),
        array("name" => "liveleak", "color" => "#dd4b39", "slug" => ""),
        array("name" => "mashable", "color" => "#0084ff", "slug" => ""),
        array("name" => "odnoklassniki", "color" => "#f57d00", "slug" => ""),
        array("name" => "pinterest", "color" => "#bf1f24", "slug" => ""),
        array("name" => "soundcloud", "color" => "#ff3300", "slug" => "", "music" => true),
        array("name" => "ted", "color" => "#e62b1e", "slug" => ""),
        array("name" => "tiktok", "color" => "#131418", "slug" => ""),
        array("name" => "tumblr", "color" => "#32506d", "slug" => ""),
        array("name" => "twitch", "color" => "#6441a5", "slug" => ""),
        array("name" => "twitter", "color" => "#00aced", "slug" => ""),
        array("name" => "vimeo", "color" => "#1ab7ea", "slug" => ""),
        array("name" => "vk", "color" => "#4a76a8", "slug" => ""),
        array("name" => "youtube", "color" => "#d82624", "slug" => ""),
    );
    return $websites;
}